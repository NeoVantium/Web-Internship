# Web-Internship

## Get a clone of the following [Website](https://www.scentsamples.uk.com/)
### Using Web Scraping Technology

## CHECK THE WEBSITE WORKING [HERE](https://neovantium.com/Web-Internship/)
